package com.atividadeAPI_REST.repository;

import com.atividadeAPI_REST.model.Aluno;
import org.springframework.data.jpa.repository.JpaRepository;


public interface AlunoRepository extends JpaRepository<Aluno, Long>{
}
