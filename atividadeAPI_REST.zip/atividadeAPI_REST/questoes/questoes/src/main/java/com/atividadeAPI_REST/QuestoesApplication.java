package com.atividadeAPI_REST;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuestoesApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuestoesApplication.class, args);
	}

}
