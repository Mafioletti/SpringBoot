package com.atividadeAPI_REST.controller;


import com.atividadeAPI_REST.model.Aluno;
import com.atividadeAPI_REST.service.AlunoService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
@RestController
@RequestMapping("/alunos")
@RequiredArgsConstructor

public class AlunoController {
    private final AlunoService service;

    @GetMapping
    public List<Aluno> listar(){
        return service.listar();
    }
    @GetMapping("/{id}")
    public ResponseEntity<Aluno> buscar(@PathVariable Long id){
        return  ResponseEntity.ok(service.buscarPorID(id));
    }
    @PostMapping
    public ResponseEntity<Aluno> salvar(@RequestBody Aluno aluno){
        return ResponseEntity.ok(service.salvar(aluno));
    }
    @PutMapping("/{id}")
    public ResponseEntity<Aluno> atualizar(@PathVariable Long id, @RequestBody Aluno dados){
        return ResponseEntity.ok(service.atualizar(id, dados));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id){
        service.excluir(id);
        return ResponseEntity.noContent().build();
    }

}
