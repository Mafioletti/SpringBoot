package com.atividadeAPI_REST.service;

import com.atividadeAPI_REST.model.Aluno;
import com.atividadeAPI_REST.repository.AlunoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor

public class AlunoService {
    private final AlunoRepository repository;

    public List<Aluno> listar(){
        return repository.findAll();
    }
    public Aluno buscarPorID(Long id){
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Aluno não encontrado"));
    }
    public  Aluno salvar(Aluno aluno){
        return repository.save(aluno);
    }
    public Aluno atualizar(Long id, Aluno dados){
        Aluno aluno = buscarPorID(id);
        aluno.setNome(dados.getNome());
        aluno.setIdade(dados.getIdade());

        return repository.save(aluno);
    }

    public void excluir(Long id){
        repository.deleteById(id);
    }
}
