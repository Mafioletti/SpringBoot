package com.atividadeAPI_REST.questoes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuestoesApplicationTests {

	@Test
	void contextLoads() {
	}

}
